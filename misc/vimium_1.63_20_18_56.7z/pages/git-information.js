branchName = "HEAD\n"
commitData = "commit 8d36c2b595c52725ee71d9badbfd636ba2c8d3b5\nAuthor: mrmr1993 <mr_1993@hotmail.co.uk>\nDate:   Sat Jan 30 12:20:23 2016 +0000\n\n    Show build date with current branch in options page for dev-build\n"
buildDate = "2016-01-30T12:28:05.609Z"